# Veyora PWA

Phone-friendly Progressive Web App version of Veyora.

## Install on Android
1. Put these files on an HTTPS website (or a local PWA-capable server).
2. Open the site in Chrome.
3. Open ⋮ and choose **Add to Home screen** or **Install app**.
4. Veyora will open in a standalone app-like window.

Note: Chrome generally requires HTTPS for service workers/PWA installation (localhost is also allowed for development).
This is still a frontend prototype; real accounts, backend, cloud media, messaging, moderation, and admin controls require a server/backend.
