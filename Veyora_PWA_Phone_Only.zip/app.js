const demo=[
{u:'Ari Stone',h:'@aristone',t:'Late evening, clear mind. ✨',n:'248',c:'32',m:true},
{u:'Mika Lee',h:'@mikalee',t:'What are you building this week?',n:'91',c:'14',m:false}
];
let posts=JSON.parse(localStorage.getItem('veyoraPosts')||'null')||demo;
function render(){document.getElementById('feed').innerHTML=posts.map(p=>`<article class="card"><div class="posthead"><div class="avatar">${p.u[0]}</div><div><b>${p.u}</b><small>${p.h} · now</small></div></div><p>${p.t}</p>${p.m?'<div class="media">VE</div>':''}<div class="actions"><button onclick="like(this)">♡ ${p.n}</button><button>◌ ${p.c}</button><button>↗ Share</button></div></article>`).join('')}
function renderThreads(){document.getElementById('threads').innerHTML=[['@nora','Small steps still count.','1.2K','87'],['@kai','Drop your best productivity tip.','632','54']].map(x=>`<div class="thread"><b>${x[0]}</b><p>${x[1]}</p><span>♡ ${x[2]} · ◌ ${x[3]}</span></div>`).join('')}
function like(b){b.textContent='♥ '+(parseInt(b.textContent.match(/\d+/)[0])+1)}
function publish(){let t=document.getElementById('text').value.trim();if(!t)return;posts.unshift({u:'You',h:'@yourhandle',t,n:'0',c:'0',m:false});localStorage.setItem('veyoraPosts',JSON.stringify(posts));document.getElementById('text').value='';render();show('home')}
function show(id){document.querySelectorAll('.page').forEach(x=>x.style.display=x.id===id?'block':'none');scrollTo(0,0)}
function search(q){/* discovery UI placeholder for backend search */}
render();renderThreads();show('home');